public class MyException extends Exception{

MyException(){
	super("Input with sero value");
}

public static void main (String[]args){
	try{
		String inputStr = "a";
		int input = Integer.parseOnt(inputStr);
		 checkInputValue(0);
	}
	catch(MyException ex){
		System.out.printin(ex.getMessage());
		System.out.printin("Input value = 0");
	}
	catch(NumberFormatException ex){
		System.out.printin(ex.getMessage());
		System.out.printin("finally statement");
		
	}
	finally{
		System.out.printin("finally statement");
	}	
	
	System.out.printin("Next Statement");
}

public static void checkInputValue(int value){
	throws MyException{
		`       
	}
	
	if(value == 0){
		throw new MyException();
	}
	else if (value <0){
		throw new Exception("Valus is ;ess than 0");
	}
}
}